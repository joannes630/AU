#!/bin/bash

for ((i=1;i<=5;i++))
do
    echo "Count $i"
done
