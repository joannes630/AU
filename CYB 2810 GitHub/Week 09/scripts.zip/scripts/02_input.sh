#!/bin/bash

read -p "Enter name: " user
echo "Hello $user"
