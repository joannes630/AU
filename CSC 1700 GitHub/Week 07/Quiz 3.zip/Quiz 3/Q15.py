"""
Restaurant Bill with Tax

Use a sentinel controlled while loop to ask the user to continuously
enter item's prices. Stop when the user enters -1.
Use a while loop to enter each item’s price and compute the subtotal.
After the loop, calculate 8% tax

Display the subtotal, tax amount, and final total.
Round all monetary values to two decimal places.
"""

