"""
Input Validation with While

Ask the user to enter a number between 1 and 10 (inclusive).
If the number is outside the range, keep asking using a while loop
until a valid number is entered. Display the valid number that is entered.
"""


