"""
Positive and Odd Number Sum

Ask the user to enter 10 numbers using a for loop.
Compute the running total only if:

the number is odd
the number is positive
Display the final running total.
"""


